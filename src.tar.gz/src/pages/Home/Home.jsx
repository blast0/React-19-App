import ColumnsLayout from "../../components/Hero/Hero";

const Home = () => {
  return (
    <div>
      <ColumnsLayout />
    </div>
  );
};

export default Home;
