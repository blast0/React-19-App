

const Profile = () => {
  return (
    <div>
      <p>This is profile page</p>
    </div>
  )
}

export default Profile
