

const Settings = () => {
  return (
    <div>
      <p>This is settigns page</p>
    </div>
  )
}

export default Settings
