const Service = () => {
  return (
    <div className="py-2 flex items-center justify-center">
      <div className="border border-gray-300 p-8 rounded-xl shadow-lg">
        <p className="text-xl font-semibold">This is the service page</p>
      </div>
    </div>
  );
};

export default Service;
