import FabricEditorPage from "../FabricEditor/Editor";
const Contact = ({ theme }) => {
  return <FabricEditorPage theme={theme} />;
};

export default Contact;
