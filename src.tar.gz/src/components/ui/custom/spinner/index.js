import Spinner from "./manager";
import Spin from "./spinner";

export { Spinner };

export default Spin;
